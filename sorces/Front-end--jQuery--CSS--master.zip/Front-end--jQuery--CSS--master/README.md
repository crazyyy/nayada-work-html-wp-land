README:
===========
This repository contains fron-end examples and exercises. Combining HTML, CSS, JavaSscript, jQuery and AJAX.