README:
=============

![Preview](http://alvarotrigo.com/blog/demos/imgs/floatingWindow.jpg)

Floating window with tabs. (CSS + jQuery)
You can see the "one file version" running in here: http://alvarotrigo.com/blog/demos/floatingWindowTabs.php